package tp;

import java.util.Random;

public class dado {
    private int numCaras;
    private double[] probabilidades;
    private Random random;

    public dado(int numCaras, double[] probabilidades) {
        if (probabilidades.length != numCaras) {
            throw new IllegalArgumentException("El tamaño del arreglo de probabilidades debe coincidir con el número de caras.");
        }

        double suma = 0.0;
        for (double p : probabilidades) {
            suma += p;
        }
        if (Math.abs(suma - 1.0) > 1e-6) { 
            throw new IllegalArgumentException("La suma de las probabilidades debe ser igual a 1.");
        }

        this.numCaras = numCaras;
        this.probabilidades = probabilidades;
        this.random = new Random();
    }

    public int tirarDado() {
        double rand = random.nextDouble(); 
        double acumulado = 0.0;

        for (int i = 0; i < numCaras; i++) {
            acumulado += probabilidades[i];
            if (rand <= acumulado) {
                return i + 1; 
            }
        }

        return numCaras;
    }

    public static void main(String[] args) {
        double[] probabilidades = {0.1, 0.2, 0.3, 0.4}; 
        dado dado = new dado(4, probabilidades);

        for (int i = 0; i < 10; i++) {
            System.out.println("Resultado del lanzamiento: " + dado.tirarDado());
        }
    }
}

